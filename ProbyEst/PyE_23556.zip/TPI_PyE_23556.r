library(UsingR)
 moda=function(x) {
    q=table(x)
    q=sort(q,TRUE)
    return(q[1])
     }
data(father.son)
summary(father.son)



x=father.son$fheight
y=father.son$sheight
n_father=length(x)
c=(max(x)-min(x))/8

print("Moda de x")
moda(round(x,digits=1))
print("Moda de y")
moda(round(y,digits=1))
breakx=seq(min(x),max(x),by=c)
x.cut= cut(x,breakx,right=FALSE)
x.freq=table(x.cut)

##Histograma de x

hhfather <- hist(x[x > min(x) & x < max(breakx)],main="Alturas de los padres",ylab="Frecuencia",col="green", breaks=breakx,freq=TRUE,include.lowest=TRUE,plot=TRUE,xlab="Altura (p)",labels=TRUE,axes=FALSE)
axis(1,at=round(breakx,digits=2),las=2,tcl=-0.5)

xprom <- head(c(hhfather$mids,8),-1)
yprom <- head(c(hhfather$counts,0),-1)
poligonox <- lines(xprom,yprom,col='red',type="b",lwd=3)

##Aca agrego el histograma de Y
cy=(max(y)-min(y))/8
breaky=seq(min(y),max(y),by=cy)
hhson <- hist(y[y > min(y) & y < max(breaky)],breaks=breaky,main="Alturas de los hijos", ylab="Frecuencia",col="blue",plot=TRUE,xlab="Altura (p)",freq=TRUE, include.lowest=TRUE,labels=TRUE,axes=FALSE)
axis(1,at=round(breaky,digits=2),las=2,tcl=-0.5)

xprom2 <- head(c(hhson$mids,8),-1)
yprom2 <- head(c(hhson$counts,0),-1)
poligonoy <-lines(xprom2,yprom2,col='green',type="b",lwd=3)

##Comparacion de poligonales
plot(poligonox,poligonoy,xlim=c(58,79),ylim=c(0,350),xlab="Altura (p)",ylab="Frecuencia")
lines(xprom,yprom,col='red',type="b",lwd=3)
lines(xprom2,yprom2,col='green',type="b",lwd=3)
legend("topright", legend=c("Padres", "Hijos"),col=c("red", "green"), lty=1, cex=0.8,merge=TRUE)

##Ahora, vamos a hacer un diagrama de dispersion

plot(x,y,pch=19,main="Diagrama de Dispersion",xlab="Alturas de Padres",ylab="Alturas de hijos")

##Representacion de grafico de caja
par(mfrow=c(1,2)) #esto divide el grafico en dos
boxplot(x,main="Altura de los padres")
boxplot(y,main="Altura de los hijos")

#Medidas de dispersion
#rangos
rangex=max(x)-min(x)
print("Rango de X")
rangex

print("Rango de Y")
rangey=max(y)-min(y)
rangey

print("Desvio estandar de X")
#Desvio estandar
DSx=sd(x)
DSx
print("Desvio estandar de Y")
DSy=sd(y)
DSy

print("Varianza de X")
#Varianza
Sx=var(x)
Sx

print("Varianza de Y")
Sy=var(y)
Sy

#Covarianza
print("Covarianza")
covar=cov(x,y)
covar

print("CV de X")
#Coeficientes de variacion
coefvarx=Sx*100/mean(x)
coefvarx

print("CV de Y")
coefvary=Sy*100/mean(y)
coefvary

print("Asimetria 1 de x")
as1x=(mean(x)-67.4)/Sx
as1x

print("Asimetria 1 de y")
as1y=(mean(y)-68.6)/Sy
as1y

print("Asimetria 2 de x")
as2x=3*(mean(x)-median(x))/Sx
as2x
print("Asimetria 2 de y")
as2y=3*(mean(y)-median(y))/Sy
as2y

#Ajuste lineal
par(mfrow=c(1,1))
plot(x,y,pch=16,col="green")
lm(y~x)
abline(lm(y~x))

#Finalmente, el coeficiente r

r=covar/(DSx*DSy)
print("Coeficiente r")
r
